char uuid[200] = "";
char symbols[16][5]; //[5];
int permissions = 0;

const char * gen_symbol()
{
	int sym = rand()%16;
	//int sym = 1;
	//return symbols[sym];
	const char * a = symbols[sym];
	//strcpy(a,symbols[sym]);
//	a = symbols[sym];
	return a;
}

bool search_symbols(char sym)
{	//return false;
	char symChar[5]="0";
	symChar[0] = sym;
	int c = 0;
	while(true)
	{
		if (strcmp(symbols[c],symChar) == 0)
		//if (symbols[c] == sym)
		{
			return true;
		}

		c = c + 1;
		if (c == 16) { break; }
	}
	return false;
}

void populate_symbols(){

	strcpy(symbols[0],"0");
	strcpy(symbols[1],"1");
	strcpy(symbols[2],"2");
	strcpy(symbols[3],"3");
	strcpy(symbols[4],"4");
	strcpy(symbols[5],"5");
	strcpy(symbols[6],"6");
	strcpy(symbols[7],"7");
	strcpy(symbols[8],"8");
	strcpy(symbols[9],"9");
	strcpy(symbols[10],"a");
	strcpy(symbols[11],"b");
	strcpy(symbols[12],"c");
	strcpy(symbols[13],"d");
	strcpy(symbols[14],"e");
	strcpy(symbols[15],"f");

/*
symbols[1] = '1';
symbols[2] = '2';
symbols[3] = '3';
symbols[4] = '4';
symbols[5] = '5';
symbols[6] = '6';
symbols[7] = '7';
symbols[8] = '8';
symbols[9] = '9';
symbols[10] = 'a';
symbols[11] =  'b';
symbols[12] = 'c';
symbols[13] = 'd';
symbols[14] = 'e';
symbols[15] = 'f';
*/

}

void russ_generate_uuid() //WORKS
{
	strcpy(uuid,"");
	strcat(uuid,gen_symbol()); //8 times
	strcat(uuid,gen_symbol()); //1
	strcat(uuid,gen_symbol()); //2
	strcat(uuid,gen_symbol());//3
	strcat(uuid,gen_symbol());//4
	strcat(uuid,gen_symbol());//5
	strcat(uuid,gen_symbol());//6
	strcat(uuid,gen_symbol());//7
	strcat(uuid,"-");			//8
	strcat(uuid,gen_symbol());//9
	strcat(uuid,gen_symbol());//10
	strcat(uuid,gen_symbol());//11
	strcat(uuid,gen_symbol()); //12
	strcat(uuid,"-");			//13
	strcat(uuid,gen_symbol()); //14
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol()); //17
	strcat(uuid,"-"); //18
	strcat(uuid,gen_symbol()); //19
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol()); //22
	strcat(uuid,"-");			//23
	strcat(uuid,gen_symbol()); //24
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol());
	strcat(uuid,gen_symbol()); //35
	//return uuid;

}
//char * check_uuid_op;

char * check_uuid(char uuid[200])
{	//return "error";
	int c = 0; //counter
	while(true)
	{
		char currentSymbol = uuid[c];
	//	char symChar[1] = "0";
	//	symChar[0] = currentSymbol;

		if ( (c >= 0 && c <= 7) //if its 0 to f
				|| (c >= 9 && c <= 12 )
				|| (c >= 14 && c <= 17 )
				|| (c >= 19 && c <= 22 )
				|| (c >= 24 && c <= 35 ) )
		{ //check that the symbol is in the list
			bool test = search_symbols(currentSymbol);
			if (test == false)
			{ //found invalid character
		//	char * text = "invalid: ";
		//	char num[10];
		//	sprintf(num,"%d",c);
		//	strcat(text,&uuid[c]);
				char text[10] = "";
				strcat(text,&currentSymbol);
			return text;
			}
		}

		//if im expecting a dash
		if ( c == 8 || c == 13 || c == 18 || c == 23)
		{
			if (currentSymbol != '-')//if its not a dash
			//	(currentSymbol != '-')

			{
				//char mytext[30] = "";
				//strcat(mytext,"need hyphen: ");
				//char num[5];
				//sprintf(num,"%d",c);
				//strcat(mytext,num);
				//return mytext;
				return "need hyphen @ 9,<br>14,19, 23"; //+1
				}

		}


		c++;
		//completion:
		if ((c == 35) && (strlen(uuid) == 36))
		{
			return "valid";
		} else if (strlen(uuid) > 36)
		{
			return "too long";
		} else if (strlen(uuid) < 36)
		{
			return "too short";
		}

		if (c>=35) { break; }
	}
	return "fail";
}

