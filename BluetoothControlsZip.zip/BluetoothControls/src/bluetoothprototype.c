#include "app_main.h"
#include <tizen.h>
#include <bluetooth.h>
#include <app_control.h>
#include <dlog.h>
//#include <glib.h> /* For GList */

//char * btAddress;
char preBondedListName[100][100];
char preBondedListAddress[100][100];
int preBondedListConnected[100];
char preBondedListIsKind[100][20];

int currentDeviceServiceSearching = 0;

//int preBondedListServiceCount[100];
//int current_device = 1;

char preBondedServiceList[100][100][100]; //device:service:uuid

//int currentlyCheckingServices = 0;

int serviceCounter = 0;
//char  services[100][100];

//char * preBondedListName[100];
//char * preBondedListAddress[100];

int currentlyBonded[100];

int discoveryStatus = 0; //0 discovering, 1 done

char deviceName[100][100];
char btAddress[100][100];
int deviceBonded[100];

//int isBonded = 0;
//int isConnected;
int isBondedList[100];
int isConnectedList[100];
int counter = -1; //bluetooth discovery item counter
int preBondedCounter = 0;
int numberOfDevices = 0; //1
char * localAddress;

bt_device_info_s *deviceInfo;

bt_hid_mouse_data_s *mouse_data;
//bt_hid_device_send_mouse_event();

bt_audio_profile_type_e bluetooth_audio;

bt_hid_key_data_s key_data;

int service_searching = 0;

char * savePath = "/opt/usr/home/owner/media/Documents/bluetooth/";

char var_font_format[500];

//BEZEL

Eina_Bool discoverView_rotary_handler_cb(); //discovery
Eina_Bool _rotary_handler_cb(); 				//spp
Eina_Bool bleScan_rotary_handler_cb(); //ble scan
Eina_Bool preBonded_rotary_handler_cb();
Eina_Bool hid_rotary_handler_cb();
Eina_Bool shell_rotary_handler_cb();
Eina_Bool mousePad_rotary_handler_cb();

Eina_Bool primaryView_rotary_handler_cb();
Eina_Bool keyB_rotary_handler_cb();

Eina_Bool services_rotary_handler_cb();
Eina_Bool deviceGatt_rotary_handler_cb();
Eina_Bool gattWrite_rotary_handler_cb();

//END BEZEL
void turn_off_rotary()
{

	eext_rotary_event_handler_del(discoverView_rotary_handler_cb); //discovery
	eext_rotary_event_handler_del(_rotary_handler_cb); 				//spp
	eext_rotary_event_handler_del(bleScan_rotary_handler_cb); //ble scan 'gattView'
	eext_rotary_event_handler_del(preBonded_rotary_handler_cb); //prebonded
	eext_rotary_event_handler_del(hid_rotary_handler_cb); //MouesSelectionView
	eext_rotary_event_handler_del(shell_rotary_handler_cb); //Shell
	eext_rotary_event_handler_del(mousePad_rotary_handler_cb); //Shell
	eext_rotary_event_handler_del(primaryView_rotary_handler_cb); //Shell
	eext_rotary_event_handler_del(keyB_rotary_handler_cb); //Shell
	eext_rotary_event_handler_del(services_rotary_handler_cb); //Shell

	eext_rotary_event_handler_del(deviceGatt_rotary_handler_cb); //Shell
	eext_rotary_event_handler_del(gattWrite_rotary_handler_cb); //Shell

}

int main(int argc, char **argv)
{
	int result = 0;
	app_data *app = uib_app_create();
	if (app)
	{
		result = uib_app_run(app, argc, argv);
		uib_app_destroy(app);
	}

	return result;
}

bt_hid_device_connection_state_changed_cb empty_cb()
{

}

void send_key_bt(char * address, int key)
{
	key_data.key[0] = key; //key dn
			key_data.modifier =0; //-1 doesnt work, 0 makes repeat letters
			bt_hid_device_send_key_event(address, &key_data);
			key_data.key[0] = 0; //NEW
			key_data.modifier = 0; //WAS
			bt_hid_device_send_key_event(address, &key_data);
}

int russ_start_bluetooth_audio(char * address) {
//char * address = preBondedListAddress[preCounter];
if (strlen(address) < 2) {return 0; }

bt_audio_initialize();
int ret = bt_audio_connect(address, bluetooth_audio);

if (ret == 0) {return 1; } else {return 0; }
}

bool adapter_bonded_device_cb(bt_device_info_s *device_info, void *user_data)
{	//iterates through devices that are bonded.
	if (device_info == NULL)
	{ return true; }


    	if (preBondedCounter > 99) {return false; } //SANITY
    	currentlyBonded[preBondedCounter] = 1;
    	strcpy(preBondedListName[preBondedCounter], device_info->remote_name);
    	strcpy(preBondedListAddress[preBondedCounter], device_info->remote_address);
    	preBondedListConnected[preBondedCounter] = device_info->is_connected;
    	preBondedCounter = preBondedCounter+1;
return true;
}

void empty_service_one_device(int device)
{
	for (int x = 0 ; x < 100 ; x++)
	{
		strcpy(preBondedServiceList[device][x],"");
	}
}

void empty_service_list()
{	//serviceCounter = 1;
//	for (int x = 1 ; x <= 100 ; x++)
//	{
//		strcpy(services[x],"");
//	}
	for (int x = 0 ; x < 100 ; x++)
	{
		for (int y = 0 ; y < 100 ; y++)
		{
			strcpy(preBondedServiceList[x][y], "");
		}
	}
}

void bluetooth_destroy_bond(char * address)
{
	bt_device_destroy_bond(address);
}
bt_device_sdp_info_s test;
void bluetooth_services_cb(int result, bt_device_sdp_info_s *sdp_info, void * user_data) //void *user_data
{	//service_searching = 1;
	int currentDevice = currentDeviceServiceSearching;
	int count = sdp_info->service_count;

	char** list = sdp_info->service_uuid;

	for(int x = 0; x < count; x++)
	{
	//serviceCounter++;
	char* uuid = *list;
	strcpy(preBondedServiceList[currentDevice][serviceCounter],uuid);
	serviceCounter++;
	++list;
	}
	/*
	if (sdp_info != NULL)
	{

		int count = sdp_info->service_count;
		char * ptr = *(sdp_info->service_uuid);

		for (int x = 1 ; x <= count ; x++)
		{
			//ptr++;
			char * uuid = ptr;
			if (strlen(uuid) > 5) //sanity
			{
				strcpy(preBondedServiceList[currentDevice][serviceCounter],uuid);
				serviceCounter++;
			}
			//ptr = ptr + 36;
			ptr++;
		} //ends for
	//strcpy(preBondedServiceList[currentDevice][serviceCounter],*sdp_info->service_uuid);
	}
*/
	//return true;
	//uib_servicesView_view_context vc;
	//animate_hourglass(vc);
return;
}

void bluetooth_services_set_cb()
{
	//bt_device_set_service
	bt_device_set_service_searched_cb(bluetooth_services_cb, NULL);
}



void bluetooth_check_services(char * address)
{

	if (strlen(address) <=2 ) {return; }
	serviceCounter = 0;
	//bt_device_set_service_searched_cb(bt_service_searched_cb, NULL);
	bt_device_start_service_search(address);


}

void start_bluetooth()
{
	bt_error_e ret;

	ret = bt_initialize();
//	if (ret != BT_ERROR_NONE)
}

int check_bluetooth_state() {
	bt_adapter_state_e bt_adapter;
	int toReturn = -1;
	//if(bt_initialize() == BT_ERROR_NONE) {

		if(bt_adapter_get_state(&bt_adapter) == BT_ERROR_NONE) {

			if(bt_adapter == BT_ADAPTER_ENABLED)
				{toReturn = 1; }//LOGI("Bluetooth enabled");
			else
				{toReturn = 0; }//LOGI("Bluetooth disabled");

	//	}
	}

	//bt_deinitialize();
	return toReturn;
}

/*
void
device_bond_created_cb(int result, bt_device_info_s *device_info, void *user_data)
{	//called on bond with address
	//isBonded = 0;

    if (result != BT_ERROR_NONE) {
        //dlog_print(DLOG_ERROR, LOG_TAG, "[bt_device_bond_created_cb] failed. result(%d).", result);

        return;
    }

    //if (device_info != NULL && !strcmp(device_info->remote_address, remote_server_address)) {
    if (device_info != NULL) {

       // dlog_print(DLOG_INFO, LOG_TAG, "Callback: A bond with chat_server is created.");
        //dlog_print(DLOG_INFO, LOG_TAG, "Callback: The number of service - %d.", device_info->service_count);
        //int i = 0;
    	//strcpy(preBondedListName[preBondedCounter], device_info->remote_name);
    	//isBonded = device_info->is_bonded;
  //      isConnected = device_info->is_connected;
        //dlog_print(DLOG_INFO, LOG_TAG, "Callback: is_bonded - %d.", device_info->is_bonded);
        //dlog_print(DLOG_INFO, LOG_TAG, "Callback: is_connected - %d.", device_info->is_connected);
    } else {
        //dlog_print(DLOG_ERROR, LOG_TAG, "Callback: A bond with another device is created.");
    }
}
*/
//DISCOVERY
void adapter_device_discovery_state_changed_cb(int result, bt_adapter_device_discovery_state_e discovery_state,
	                                          bt_adapter_device_discovery_info_s *discovery_info, void* user_data)
	{


	    if (result != BT_ERROR_NONE) {
	        //dlog_print(DLOG_ERROR, LOG_TAG, "[adapter_device_discovery_state_changed_cb] failed! result(%d).", result);

	        return;
	    }
	    //GList** searched_device_list = (GList**)user_data;
	    switch (discovery_state) {
	    case BT_ADAPTER_DEVICE_DISCOVERY_STARTED:
	    	discoveryStatus = 0;
	        //dlog_print(DLOG_INFO, LOG_TAG, "BT_ADAPTER_DEVICE_DISCOVERY_STARTED");
	        break;
	    case BT_ADAPTER_DEVICE_DISCOVERY_FINISHED:
	    	discoveryStatus = 1;
		    numberOfDevices = counter; //works
		    counter = -1; //default -1

		    //elm_object_text_set(user_data->label6,_UIB_LOCALE("Done"));
	        //dlog_print(DLOG_INFO, LOG_TAG, "BT_ADAPTER_DEVICE_DISCOVERY_FINISHED");
	        break;
	    case BT_ADAPTER_DEVICE_DISCOVERY_FOUND:
	        //dlog_print(DLOG_INFO, LOG_TAG, "BT_ADAPTER_DEVICE_DISCOVERY_FOUND");
	        if (discovery_info != NULL) {
	        	counter++; //first cast item[0]
	        	//counter = counter +1; //first entry is 1 or counter + 1 (0)
	        	if (counter > 99) {return; } //SANITY FOR 100+ devices nearby
	        	strcpy(btAddress[counter],discovery_info->remote_address);
	        	strcpy(deviceName[counter],discovery_info->remote_name);
	        	deviceBonded[counter] = discovery_info->is_bonded;

	        }
	        break;
	    }

	}



void russ_bluetooth_set_discovery_cb()
{
	//GList *devices_list = NULL;
	bt_adapter_set_device_discovery_state_changed_cb(adapter_device_discovery_state_changed_cb, NULL);


	//bt_adapter_foreach_bonded_device(adapter_bonded_device_cb, NULL);
	//if (ret != BT_ERROR_NONE)
	    //dlog_print(DLOG_ERROR, LOG_TAG, "[bt_adapter_foreach_bonded_device] failed!");
}

void empty_prebonded_list()
{
	preBondedCounter = 0; //reset counter

	for (int x = 0 ; x <= 100 ; x++)
	{
		strcpy(preBondedListName[x], "");
		strcpy(preBondedListAddress[x], "");
//		preBondedListServiceCount[x] = 0;
		preBondedListConnected[x] = 0;
		currentlyBonded[x] = 0;

	}
}

void russ_refresh_bonded_devices()
{
	empty_prebonded_list();
	bt_adapter_foreach_bonded_device(adapter_bonded_device_cb, NULL);
/*
	for(int x = 1; x <= preBondedCounter ; x++)
	{
		//check the device services
		char * address = preBondedListAddress[x];
		if (strlen(address) <= 2) {break; }
		if (strlen(address) > 2) {
			current_device = x;
		bt_device_start_service_search(address);
		}

	}
*/

}

void russ_start_discovery()
{
	//bt_deinitialize();
		//bt_initialize();
		//russ_discover_main_view(vc);
		//bt_adapter_stop_device_discovery();
		bt_adapter_start_device_discovery();
}

int device_bluetooth_menu()
{

    int ret = 0;
    app_control_h service = NULL;
    app_control_create(&service);
    if (service == NULL) {
        dlog_print(DLOG_INFO, LOG_TAG, "service_create failed!\n");

        return 0;
    }
    app_control_set_operation(service, APP_CONTROL_OPERATION_SETTING_BT_ENABLE);
    ret = app_control_send_launch_request(service, NULL, NULL);

    app_control_destroy(service);
    if (ret == APP_CONTROL_ERROR_NONE) {
        dlog_print(DLOG_INFO, LOG_TAG, "Succeeded to Bluetooth On/Off app!\n");

        return 0;
    } else {
        dlog_print(DLOG_INFO, LOG_TAG, "Failed to relaunch Bluetooth On/Off app!\n");

        return -1;
    }

    return 0;
}


void bluetooth_ready()
{
	bt_adapter_state_e adapter_state;

	/* Check whether the Bluetooth adapter is enabled */
	int ret = bt_adapter_get_state(&adapter_state);
	if (ret != BT_ERROR_NONE) {
	    dlog_print(DLOG_ERROR, LOG_TAG, "[bt_adapter_get_state] failed");

	    return;
	}
	/* If the Bluetooth adapter is not enabled */
	if (adapter_state == BT_ADAPTER_DISABLED)
	    dlog_print(DLOG_ERROR, LOG_TAG, "Bluetooth adapter is not enabled. You should enable Bluetooth!!");
}

int load_value(char * fileN)
{
	//char * savePath = "/opt/usr/home/owner/media/Documents/";

	int vary;
	//load or initialize iron value for first time / consecutive plays

	// construct the path to the file where the resource integer is stored
	char mydir[100]= "";
	strcat(mydir,savePath);
	strcat(mydir,fileN);

	//file = dir.resolve(mydir);
	FILE *datafile = fopen(mydir,"r");

	if(datafile) {
		char ironstr[12];
		fgets(ironstr,12,datafile); //read the iron value from file
		vary = atoi(ironstr);
	}else{
	vary = -1 ; //load failed
	}
	if(datafile){ fclose(datafile); }
return vary;
}

void save_value(char * fileN,int vary)
{
char path[100] = "";
strcat(path,savePath);
strcat(path,fileN);

FILE *datafile = fopen(path,"w");

fprintf(datafile,"%d",vary);

if(datafile){ fclose(datafile); };

}

void get_font_format_output(int fontS,char * style, char * color) //loads var_font_format string
{
	strcpy(var_font_format,"");
	//set font to entry
	char fontSize[10];
	eina_convert_itoa(fontS,fontSize);

	/*
	char * style;
	if (var_output_font_style == 1)
	{style = "Bold"; } else if
	(var_output_font_style == 2)
	{style = "Regular"; } else if
	(var_output_font_style == 3) {
	style = "Light";
	}else if
	(var_output_font_style == 4) {
	style = "Condensed";
	}
	*/
	//load the font to entry
//	char myStr[500] = "";
	//strcat(var_font_format,"DEFAULT='font=Tizen:style=Light font_size=");

		strcat(var_font_format,"DEFAULT='font=Tizen:style="); //W
		strcat(var_font_format,style);

	strcat(var_font_format," font_size=");
	strcat(var_font_format,fontSize);
	strcat(var_font_format," color=#");
	strcat(var_font_format,color);
	strcat(var_font_format, " align=left'");
}
