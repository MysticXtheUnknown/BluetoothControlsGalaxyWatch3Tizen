

#ifndef __VIEW_DATA_H__
#define __VIEW_DATA_H__

#include <Elementary.h>
#include "uib_views.h"

/**
 * @brief Forward declaration of model
 */
typedef struct _uib_view_data {
	Evas_Object* win;

	uib_view_context* view1;
	uib_view_context* preBondedView;
	uib_view_context* primaryView;
	uib_view_context* nameView;
	uib_view_context* servicesView;
	uib_view_context* mouseView;
	uib_view_context* MouseSelectionView;
	uib_view_context* keyboardView;
	uib_view_context* sppView;
	uib_view_context* rfcommOptView;
	uib_view_context* NFCview;
	uib_view_context* BLEview;
	uib_view_context* MouseOptsView;
	uib_view_context* gattView;
	uib_view_context* deviceGattView;
	uib_view_context* gattWriteView;
	uib_view_context* HDPview;
	uib_view_context* xipspView;
	uib_view_context* cmdShellView;
	uib_view_context* shellInfoView;
	uib_view_context* audioControlView;
	uib_view_context* shellOptionsView;
	uib_view_context* mousePadView;
	uib_view_context* iotView;
	uib_view_context* audioVideoRemoteControlView;
	uib_view_context* OppRecieveView;
	uib_view_context* GattServerView;
	uib_view_context* gattServerAddServiceView;
	uib_view_context* GattServerAddCharView;
	uib_view_context* GattServerAddCharPart2View;
	uib_view_context* GattServerAddProperties;
	uib_view_context* GattServerAddValueToCharView;
	uib_view_context* GattServerAddDescriptorToCharView;
	uib_view_context* gattServerEditServices;
	uib_view_context* empty;
	uib_view_context* gattServerUUIDforService;
	uib_view_context* gattServerServiceOptionsView;
} uib_view_data;

static uib_view_data* view_data;

uib_view_data* get_uib_view_data();

#endif /* __VIEW_DATA_H__ */

